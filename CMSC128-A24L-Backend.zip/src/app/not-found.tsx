export default function NotFound() {
  return (
    <div className="flex flex-row min-h-screen justify-center items-center">
      <h1 className="text-3xl text-black">Page cannot be accessed!</h1>
    </div>
  );
}
