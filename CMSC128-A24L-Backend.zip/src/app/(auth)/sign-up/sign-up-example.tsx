import RegistrationForm from "./sign-up-form";

export default function SignUpExample() {
  return (
    <div className="flex flex-col gap-4 min-h-screen justify-center items-center p-24">
      <RegistrationForm />
    </div>
  );
}
