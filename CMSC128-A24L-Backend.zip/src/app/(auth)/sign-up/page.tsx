import SignUpExample from "./sign-up-example";

export default function SignupPage() {
  return (
    <>

      <SignUpExample />
    </>
  );
}
