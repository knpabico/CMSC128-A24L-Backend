import LoginForm from "./login-form";

export default function LoginExample() {
  return (
    <div className="flex flex-col gap-4 min-h-screen justify-center items-center p-24">
      <LoginForm />
    </div>
  );
}
