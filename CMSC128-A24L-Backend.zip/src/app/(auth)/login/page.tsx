import LoginExample from "./login-example";

export default function LoginPage() {
  return (
    <>
      <LoginExample />
    </>
  );
}
