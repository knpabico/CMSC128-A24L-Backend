export default function LoadingPage() {
  return (
    <div className="flex flex-row min-h-screen justify-center items-center">
      <h1 className="text-black text-[50px] font-semibold">Loading...</h1>
    </div>
  );
}
